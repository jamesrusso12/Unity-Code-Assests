﻿using UnityEngine;


public class ShooterMechanic : MonoBehaviour
//www.youtube.com/watch?v=PUpC44Q64zY
{
    [SerializeField] public float attackCooldown;
    [SerializeField] public Transform Lazerpoint;
    [SerializeField] public GameObject[] Lazers;

    public Animator anim;
    public PlayerMovement playerMovement;
    public float cooldownTimer = Mathf.Infinity;
    public GameObject LazerBolt;


    public void Awake()
    {
        anim = GetComponent<Animator>();
        playerMovement = GetComponent<PlayerMovement>();
    }


    public void Update()
    {
        if (Input.GetMouseButton(0) && cooldownTimer > attackCooldown && playerMovement.canAttack())
            Attack();

        cooldownTimer += Time.deltaTime;
    }


    public void Attack()
    {
        //anim.SetTrigger("attack");
        cooldownTimer = 0;

        GameObject LazerBoltClone = Instantiate(LazerBolt);
        LazerBoltClone.transform.position = Lazerpoint.position;
        
        LazerBoltClone.GetComponent<BulletMechanic>().SetDirection(Mathf.Sign(transform.localScale.x));

    }

   
   
    


}