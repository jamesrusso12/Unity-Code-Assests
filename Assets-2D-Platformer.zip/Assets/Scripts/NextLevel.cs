using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevel : MonoBehaviour
{ 
    // Start is called before the first frame update
    public void Start()
    {
        
    }
    public void OnTriggerStay2D (Collider2D other)
    {
        
        if (other.gameObject.tag == "Player" && Input.GetKeyDown(KeyCode.E))
        {
            SceneManager.LoadScene("Level 2");
            print("NextLevel");
        }
            
         
    }

    // Update is called once per frame
    void Update()
    {
       
    }
}