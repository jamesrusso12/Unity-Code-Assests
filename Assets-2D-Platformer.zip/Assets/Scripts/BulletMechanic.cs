﻿using UnityEngine;

public class BulletMechanic : MonoBehaviour
//www.youtube.com/watch?v=PUpC44Q64zY
{
    public float speed = 100;
    public float direction;

    public Animator anim;


    public void Awake()
    {
        //will eventually have animaiton for bullet collision 
        anim = GetComponent<Animator>();
    }

    public void Update()
    {
        float movementSpeed = speed * Time.deltaTime * direction;
        transform.Translate(movementSpeed, 0, 0);
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        //will eventually add explosion animation
        //anim.SetTrigger('explode');
        Destroy(gameObject);

        if (collision.tag == "Enemy")
        {
            Destroy(collision.gameObject);
        }
    }

    public void SetDirection(float _direction)
    {
        direction =  _direction;
        gameObject.SetActive(true);
    }

    public void Deactivate()
    {
        gameObject.SetActive(false);

    }

 
}
