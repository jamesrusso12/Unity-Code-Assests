using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleScreen : MonoBehaviour
//www.youtube.com/watch?v=zc8ac_qUXQY
{
    public void PlayButton ()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void QuitButton()
    {
        Debug.Log("QUIT");
        Application.Quit();
    }
}
