﻿using UnityEngine;

public class ItemCollection : MonoBehaviour
{
    public void Start()
    {
        print("startedweaponcollection");
    }
    public void OnTriggerStay2D(Collider2D other)
    {
        print("collided");
        print(other.gameObject.tag);
        if (other.gameObject.tag == "Ammo" && Input.GetKeyDown(KeyCode.E))
        {
            print("Ammo");
            Destroy(other.gameObject);
        }
    }

}