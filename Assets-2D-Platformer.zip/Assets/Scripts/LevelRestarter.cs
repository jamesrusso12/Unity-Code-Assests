﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace UnityStandardAssets._2D

{
    public class LevelRestarter : MonoBehaviour
    {
        public void OnTriggerEnter2D(Collider2D other)
        {
            print("LevelRestart");
            if (other.CompareTag("Player"))
            {
                SceneManager.LoadScene(SceneManager.GetSceneAt(0).name);
            }
        }
    }
}
