﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public Sprite StartButton;
    public Sprite StartButtonPressed;

    public void PlayGame()
    {
        SceneManager.LoadScene(1);
    }

    public void QuitGame()
    {
        //Application.Quit();
        Debug.Log("Quit");
    }

    void OnMouseDown()
    {
        SceneManager.LoadScene("MainMenuStartScreen");
    }
    void OnMouseOver()
    {
        SpriteRenderer sr = gameObject.GetComponent<SpriteRenderer>();
        sr.sprite = StartButtonPressed;
    }

    void OnMouseExit()
    {
        SpriteRenderer sr = gameObject.GetComponent<SpriteRenderer>();
        sr.sprite = StartButton;
    }

    // Update is called once per frame
    void Update()
    {

    }
}
