﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundCheck : MonoBehaviour

{
    GameObject Player;

    public void Start()
    {
        Player = gameObject.transform.parent.gameObject;
    }
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Ground" || collision.collider.tag == "Platform")
        {
            //Player.GetComponent<Movement2D>().isGrounded = true;
        }
    }

    public void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.tag == "Ground" || collision.collider.tag == "Platform")
        {
            //Player.GetComponent<Movement2D>().isGrounded = false;
        }
    }
}
