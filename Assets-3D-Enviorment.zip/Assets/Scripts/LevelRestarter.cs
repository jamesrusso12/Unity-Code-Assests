using System;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace UnityStandardAssets._2D

{
    public class LevelRestarter : MonoBehaviour
    {
        public void OnTriggerEnter(Collider other)
        {
            print("LevelRestart");
            if (other.CompareTag("Player"))
            {
                SceneManager.LoadScene(SceneManager.GetSceneAt(0).name);
            }
        }
    }
}
