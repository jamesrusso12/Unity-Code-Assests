using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;   

public class TextSpawn : MonoBehaviour
{

    public Canvas EPromptCanvas;

    void OnTriggerEnter(Collider TheThingEnteringTheTrigger) 
    {
        
        if (TheThingEnteringTheTrigger.tag == "Player") 
        {
            Debug.Log("Player is by the photo");
            EPromptCanvas.enabled=true;
        }
    }

    void OnTriggerExit(Collider TheThingLeaving)
    {
        if(TheThingLeaving.tag == "Player")
        {
            Debug.Log("The player has left the photo");
            EPromptCanvas.enabled = false;
        }
    }

}
